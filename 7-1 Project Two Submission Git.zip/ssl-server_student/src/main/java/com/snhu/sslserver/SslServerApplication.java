package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.server.Ssl;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

@SpringBootApplication
@RestController
@RequestMapping("/")
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }

    @GetMapping("/hash")
    public String getChecksum() {
        String data = "Nate Bennett";
        String checksum = calculateChecksum(data);
        return data + ":\nChecksum: " + checksum;
    }

    private String calculateChecksum(String data) {
        try {
            // This should generate AES key from the data.
            byte[] aesKey = generateAesKey(data);

            // This should encrypt the data using AES.
            byte[] encryptedData = encryptWithAes(data, aesKey);

            // This should hash the encrypted data using SHA-256.
            String checksum = hashWithSha256(encryptedData);

            return checksum;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private byte[] generateAesKey(String data) throws NoSuchAlgorithmException {
        // Generate a SHA-256 hash of the data
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));

        // Use the first 16 bytes of the hash as the AES key
        return Arrays.copyOf(hash, 16);
    }

    private byte[] encryptWithAes(String data, byte[] key) throws Exception {
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
        return cipher.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    private String hashWithSha256(byte[] data) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data);
        return Base64.getEncoder().encodeToString(hash);
    }

    @Bean
    public WebServerFactoryCustomizer<ConfigurableServletWebServerFactory> webServerFactoryCustomizer() {
        return factory -> {
            Ssl ssl = new Ssl();
            ssl.setEnabled(true);
            ssl.setKeyStore("keystore.jks");
            ssl.setKeyStorePassword("Android");
            ssl.setKeyStoreType("JKS");
            ssl.setKeyAlias("sslserver");
            factory.setSsl(ssl);
            factory.setPort(8443);
        };
    }
}

